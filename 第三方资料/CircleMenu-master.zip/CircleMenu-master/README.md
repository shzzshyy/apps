# CircleMenu
----
一款简单的圆形菜单，可以随手势任意旋转，代码仅100行.<br/>
![gif图片](https://github.com/YLYwoaini/CircleMenu/blob/master/Image/rotation.gif)
